<section class="page detailPage filterJewelry" style="display: none;">
    <div class="inner_contentDetial">
    	<div class="bg_overlay"></div>
        <div class="content_view">
        	<?php include("modules/includes/filter.php");?>
        </div>
    </div>
    
</section>