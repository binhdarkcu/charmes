<section class="page detailPage wedding">
    <div class="inner_contentDetial">
    	<div class="bg_overlay"></div>
        <div class="content_view" style="height: 75%!important;">
        	<div class="content_width content_wedding">
	        	<article class="desc animated">
	                <h5 class="title">Guides to your perfect engagement moment!</h3>
	                <ul class="list_item">
	                    <li class="flowerBox"><a >Search for your perfect engagement rings</a></li>
	                    <li class="ringBox"><a>Explore Albert Lavenda’s engagement rings gallery </a></li>
	                    <li class="peopleBox"><a>Consult Albert Lavenda’s engagement jewelries expert</a></li>
	                    <li><a>Customize your engagement rings</a></li>
	                    <li><a>Plan your perfect engagement moment</a></li>
	                </ul>
	            </article>
	            <div class="img_block animated" id="flowerBox"><img src="images/wedding/flower.jpg"></div>
	            <div class="img_block animated hide" id="ringBox"><img src="images/wedding/ring.jpg"></div>
	            <div class="img_block animated hide" id="peopleBox"><img src="images/wedding/img_view_2.png"></div>
	          </div>
        </div>
    </div>
    
</section>