<section class="page introPage">
	<div class="inner_content">
    	<ul class="list_collec">
        	<li class="introView01">
            	<div class="col1 txtCol notViewed animBlock delay" data-position="left" data-offset="-150" ><p>Gemstone <br>Knowledges</p></div>
        		<div class="col2 imgCol notViewed animBlock" data-position="right" data-offset="-150"><img src="images/gemstone.png"></div>
        		<div class="clear"></div>
            </li>
            <li class="introView02">
            	<div class="col1 imgCol w1 notViewed animBlock" data-position="left"><img src="images/precious.png"></div>
        		<div class="col2 txtCol notViewed animBlock delay" data-position="right"><p>Precious Metal<br>Expertises</p></div>
        		<div class="clear"></div>
            </li>
            <li class="introView03">
            	<div class="col1 txtCol notViewed animBlock delay" data-position="left"><p>Precision in<br>Craftsmanship</p></div>
        		<div class="col2 imgCol notViewed animBlock" data-position="right"><img src="images/precision.png" style="width: 100%;"></div>
        		<div class="clear"></div>
            </li>
            <li class="introView04">
            	<div class="col1 imgCol w2 notViewed animBlock" data-position="left"><img src="images/conceptual.png"></div>
        		<div class="col2 txtCol notViewed animBlock delay" data-position="right"><p>Conceptual<br>Aesthetics</p></div>
        		<div class="clear"></div>
            </li>
            <li class="introView05">
            	<div class="col1 txtCol notViewed animBlock delay" data-position="left"><p>Meticulous<br>Quality Control</p></div>
        		<div class="col2 imgCol notViewed animBlock" data-position="right"><img src="images/meticulous.png"></div>
        		<div class="clear"></div>
            </li>
            <li class="introView06">
            	<div class="col1 imgCol notViewed animBlock" data-position="left"><img src="images/warranty.png"></div>
        		<div class="col2 txtCol notViewed animBlock delay" data-position="right"><p class="sp01">Warranty<br>Certificates</p></div>
        		<div class="clear"></div>
            </li>
        </ul>
    </div>
</section>