<section class="left_menu">
	<div class="inner">
        <div class="social-icon connect-icon">
        	<span>Share this page's contents <br/> to friends via social media </span>
        	<div class="social-box">
            	<a href="#" class="fb"></a>
            	<a href="#" class="tw"></a>
            	<a href="#" class="insta"></a>
            	<a href="#" class="other"></a>
            </div>
        </div>
        <div class="social-icon chat-icon">
        	<span>Send your request to our<br/>customer-care supporters</span>
 			<div class="request_box">
 				<textarea name="" placeholder="Type your request here"></textarea>
 				<input type="text" name="" value="" placeholder="Your email (required) "/>
 				<input type="submit" value="Send"/>
        	</div>
        </div>
    </div>
    
</section>