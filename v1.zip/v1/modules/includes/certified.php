<div class="popup view_certified" id="pp_certified">
	<div class="shadow_pp"></div>
	<div class="popup_content">
		<div class="certified_content">
			<a href="javascript:void(0)" onclick="popup.closePopup();" class="close"></a>
			<div id="large_images"><img src="images/detail/certified.png"/></div>
		</div>
	</div>
</div>