			<div class="store-filter">
            	<a class="icon storeicon"><span></span></a>
            	<form action="" method="">
            	<div class="pad">
            		<h3>Refine your search with jewelry features below</h3>
            		<div class="colbox">
	            		<div class="col col01">
		            		<h4>Special Events</h4>
	            			<ul>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="special-events" value="" id="special01" />
		                                <label for="special01">Engagement</label>
		                            </div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
			            				 <input name="special-events" type="checkbox" id="special02">
			          					<label for="special02">Wedding</label>
		          					</div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
			            				 <input name="special-events" type="checkbox" id="special03">
			          					<label for="special03">Birthday</label>
		          					</div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
			            				 <input name="special-events" type="checkbox" id="special04">
			          					<label for="special04">Mother’s day</label>
			          				</div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
			            				 <input name="special-events" type="checkbox" id="special05">
			          					<label for="special05">Christmas</label>
			          				</div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
			            				 <input name="special-events" type="checkbox" id="special06">
			          					<label for="special06">Anniversary</label>
			          				</div>
		            			</li>
		            		</ul>
	            		</div>
	            		<div class="col col02">
	            			<h4>Categories</h4>
		            		<ul>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="category-events" value="" id="category01" />
		                                <label for="category01">Rings</label>
		                            </div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="category-events" value="" id="category02" />
		                                <label for="category02">Bracelets</label>
		                            </div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="category-events" value="" id="category03" />
		                                <label for="category03">Necklaces</label>
		                            </div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="category-events" value="" id="category04" />
		                                <label for="category04">Earrings</label>
		                            </div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="category-events" value="" id="category05" />
		                                <label for="category05">Chains</label>
		                            </div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="category-events" value="" id="category06" />
		                                <label for="category06">Pendants</label>
		                            </div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="category-events" value="" id="category07" />
		                                <label for="category07">Broochies</label>
		                            </div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="category-events" value="" id="category08" />
		                                <label for="category08">Charms</label>
		                            </div>
		            			</li>
		            		</ul>
		            	</div>
		            	<div class="col col03">
		            		<h4>Collections</h4>
		            		<ul>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="collection-events" value="" id="collection01" />
		                                <label for="collection01">Le Jardin</label>
		                            </div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="collection-events" value="" id="collection02" />
		                                <label for="collection02">Aladdin</label>
		                            </div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="collection-events" value="" id="collection03" />
		                                <label for="collection03">Safari</label>
		                            </div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="collection-events" value="" id="collection04" />
		                                <label for="collection04">Éclair</label>
		                            </div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="collection-events" value="" id="collection05" />
		                                <label for="collection05">Trés Chér</label>
		                            </div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="collection-events" value="" id="collection06" />
		                                <label for="collection06">Happy Diamond</label>
		                            </div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="collection-events" value="" id="collection07" />
		                                <label for="collection07">Alphabets</label>
		                            </div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="collection-events" value="" id="collection08" />
		                                <label for="collection08">Lolly Forever</label>
		                            </div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="collection-events" value="" id="collection09" />
		                                <label for="collection09	">Mesh is Beautiful</label>
		                            </div>
		            			</li>
	            			</ul>
	            		</div>
	            		<div class="col col04">
	            			<h4>Precious Metal</h4>
		            		<ul>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="precious-events" value="" id="precious01" />
		                                <label for="precious01">Le Jardin</label>
		                            </div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="precious-events" value="" id="precious02" />
		                                <label for="precious02">Aladdin</label>
		                            </div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="precious-events" value="" id="precious03" />
		                                <label for="precious03">Safari</label>
		                            </div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="precious-events" value="" id="precious04" />
		                                <label for="precious04">Éclair</label>
		                            </div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="precious-events" value="" id="precious05" />
		                                <label for="precious05">Trés Chér</label>
		                            </div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="precious-events" value="" id="precious06" />
		                                <label for="precious06">Happy Diamond</label>
		                            </div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="precious-events" value="" id="precious07" />
		                                <label for="precious07">Alphabets</label>
		                            </div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="precious-events" value="" id="precious08" />
		                                <label for="precious08">Lolly Forever</label>
		                            </div>
		            			</li>
		            			<li>
		            				<div class="iCheck">
		                                <input type="checkbox" name="precious-events" value="" id="precious09" />
		                                <label for="precious09">Mesh is Beautiful</label>
		                            </div>
		            			</li>
		            		</ul>
		            	</div>
		            	<div class="col col05">
	            		<h4>Gem Stones</h4>
	            		<ul>
	            			<li>
	            				<div class="iCheck">
	                                <input type="checkbox" name="collection-events" value="" id="collection01" />
	                                <label for="collection01">Le Jardin</label>
	                            </div>
	            			</li>
	            			<li>
	            				<div class="iCheck">
	                                <input type="checkbox" name="collection-events" value="" id="collection02" />
	                                <label for="collection02">Aladdin</label>
	                            </div>
	            			</li>
	            			<li>
	            				<div class="iCheck">
	                                <input type="checkbox" name="collection-events" value="" id="collection03" />
	                                <label for="collection03">Safari</label>
	                            </div>
	            			</li>
	            			<li>
	            				<div class="iCheck">
	                                <input type="checkbox" name="collection-events" value="" id="collection04" />
	                                <label for="collection04">Éclair</label>
	                            </div>
	            			</li>
	            			<li>
	            				<div class="iCheck">
	                                <input type="checkbox" name="collection-events" value="" id="collection05" />
	                                <label for="collection05">Trés Chér</label>
	                            </div>
	            			</li>
	            			<li>
	            				<div class="iCheck">
	                                <input type="checkbox" name="collection-events" value="" id="collection06" />
	                                <label for="collection06">Happy Diamond</label>
	                            </div>
	            			</li>
	            			<li>
	            				<div class="iCheck">
	                                <input type="checkbox" name="collection-events" value="" id="collection07" />
	                                <label for="collection07">Alphabets</label>
	                            </div>
	            			</li>
	            			<li>
	            				<div class="iCheck">
	                                <input type="checkbox" name="collection-events" value="" id="collection08" />
	                                <label for="collection08">Lolly Forever</label>
	                            </div>
	            			</li>
	            			<li>
	            				<div class="iCheck">
	                                <input type="checkbox" name="collection-events" value="" id="collection09" />
	                                <label for="collection09	">Mesh is Beautiful</label>
	                            </div>
	            			</li>
	            			<li>
	            				<div class="iCheck">
	                                <input type="checkbox" name="collection-events" value="" id="collection01" />
	                                <label for="collection01">Le Jardin</label>
	                            </div>
	            			</li>
	            			<li>
	            				<div class="iCheck">
	                                <input type="checkbox" name="collection-events" value="" id="collection02" />
	                                <label for="collection02">Aladdin</label>
	                            </div>
	            			</li>
	            			<li>
	            				<div class="iCheck">
	                                <input type="checkbox" name="collection-events" value="" id="collection03" />
	                                <label for="collection03">Safari</label>
	                            </div>
	            			</li>
	            			<li>
	            				<div class="iCheck">
	                                <input type="checkbox" name="collection-events" value="" id="collection04" />
	                                <label for="collection04">Éclair</label>
	                            </div>
	            			</li>
	            			<li>
	            				<div class="iCheck">
	                                <input type="checkbox" name="collection-events" value="" id="collection05" />
	                                <label for="collection05">Trés Chér</label>
	                            </div>
	            			</li>
	            			<li>
	            				<div class="iCheck">
	                                <input type="checkbox" name="collection-events" value="" id="collection06" />
	                                <label for="collection06">Happy Diamond</label>
	                            </div>
	            			</li>
	            			<li>
	            				<div class="iCheck">
	                                <input type="checkbox" name="collection-events" value="" id="collection07" />
	                                <label for="collection07">Alphabets</label>
	                            </div>
	            			</li>
	            			<li>
	            				<div class="iCheck">
	                                <input type="checkbox" name="collection-events" value="" id="collection08" />
	                                <label for="collection08">Lolly Forever</label>
	                            </div>
	            			</li>
	            			<li>
	            				<div class="iCheck">
	                                <input type="checkbox" name="collection-events" value="" id="collection09" />
	                                <label for="collection09	">Mesh is Beautiful</label>
	                            </div>
	            			</li>
	            		</ul>
	            	</div>
            		</div>
            		<div class="btnSubmit">
            			<a href="#">
            				<i class="top"></i>
            				<i class="left"></i>
            				<i class="right"></i>
            				<i class="bottom"></i>
            				<span>Show Jewelries</span>
            			</a>
            		</div>
            	</div>
            	</form>
            </div>