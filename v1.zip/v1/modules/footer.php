<footer class="footer">
	<div class="social">
        	<a class="face-icon"></a>
        	<a class="twitter-icon"></a>
        	<a class="NO-icon"></a>
    </div>
    <div class="inner">
    	
        <ul class="list_menufooter">
        	<li><a>Copyright © 2015</a></li>
        </ul>
        <a class="contact">Contact</a>
        
    </div>
</footer>