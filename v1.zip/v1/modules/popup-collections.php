﻿<section class="popup-collections page detailPage" style="display: none;">
    <div class="inner_contentDetial">
    	<div class="bg_overlay"></div>
        <div class="content_view">
        	<article  id="my-thumbs-list" class="content mThumbnailScroller">
        		<div class="left-shadow"></div>
                <ul class="list_item_collections">
                    <li>
                    	<a href="#">
                    		<img src="images/collections/p-1.jpg"/>
                    		<div>Éclair</div>
                    	</a>
                    	<div class="link">
                			<a href="#" class="link01"><span>Discover theme</span><i></i></a>
                			<a href="#" class="link02"><span>Explore jewelleries</span><i></i></a>
                		</div>
                    </li>
                    <li class="">
                    	<a href="#">
                    		<img src="images/collections/p-2.jpg"/>
                    		<div>Safari</div>
                    	</a>
                    	<div class="link">
                			<a href="#" class="link01"><span>Discover theme</span><i></i></a>
                			<a href="#" class="link02"><span>Explore jewelleries</span><i></i></a>
                		</div>
                    </li>
                    <li>
                    	<a href="#">
                    		<img src="images/collections/p-3.jpg"/>
                    		<div>Le jardin</div>
                    	</a>
                    	<div class="link">
                			<a href="#" class="link01"><span>Discover theme</span><i></i></a>
                			<a href="#" class="link02"><span>Explore jewelleries</span><i></i></a>
                		</div>
                    </li>
                    <li>
                    	<a href="#">
                    		<img src="images/collections/p-4.jpg"/>
                    		<div>Éclair</div>
                    	</a>
                    	<div class="link">
                			<a href="#" class="link01"><span>Discover theme</span><i></i></a>
                			<a href="#" class="link02"><span>Explore jewelleries</span><i></i></a>
                		</div>
                    </li>
                    <li>
                    	<a href="#">
                    		<img src="images/collections/p-5.jpg"/>
                    		<div>Trés Chér</div>
                    	</a>
                    	<div class="link">
                			<a href="#" class="link01"><span>Discover theme</span><i></i></a>
                			<a href="#" class="link02"><span>Explore jewelleries</span><i></i></a>
                		</div>
                    </li>
                    <li>
                    	<a href="#">
                    		<img src="images/collections/p-1.jpg"/>
                    		<div>Éclair</div>
                    	</a>
                    	<div class="link">
                			<a href="#" class="link01"><span>Discover theme</span><i></i></a>
                			<a href="#" class="link02"><span>Explore jewelleries</span><i></i></a>
                		</div>
                    </li>
                    <li>
                    	<a href="#">
                    		<img src="images/collections/p-2.jpg"/>
                    		<div>Safari</div>
                    	</a>
                    	<div class="link">
                			<a href="#" class="link01"><span>Discover theme</span><i></i></a>
                			<a href="#" class="link02"><span>Explore jewelleries</span><i></i></a>
                		</div>
                    </li>
                    <li>
                    	<a href="#">
                    		<img src="images/collections/p-3.jpg"/>
                    		<div>Le jardin</div>
                    	</a>
                    	<div class="link">
                			<a href="#" class="link01"><span>Discover theme</span><i></i></a>
                			<a href="#" class="link02"><span>Explore jewelleries</span><i></i></a>
                		</div>
                    </li>
                    <li>
                    	<a href="#">
                    		<img src="images/collections/p-4.jpg"/>
                    		<div>Éclair</div>
                    	</a>
                    	<div class="link">
                			<a href="#" class="link01"><span>Discover theme</span><i></i></a>
                			<a href="#" class="link02"><span>Explore jewelleries</span><i></i></a>
                		</div>
                    </li>
                    <li>
                    	<a href="#">
                    		<img src="images/collections/p-5.jpg"/>
                    		<div>Trés Chér</div>
                    	</a>
                    	<div class="link">
                			<a href="#" class="link01"><span>Discover theme</span></span><i></i></a>
                			<a href="#" class="link02"><span>Explore jewelleries</span><i></i></a>
                		</div>
                    </li>
                </ul>
                <div class="right-shadow"></div>
            </article>
        </div>
    </div>
    
</section>