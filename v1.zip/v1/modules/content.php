<?php
	include("intropage.php");
	include("store.php");
	include("collections.php");
	include("footer.php");
	include("menu_left.php");
?>