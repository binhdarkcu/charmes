<section class="page detailPage about" style="display: none;">
    <div class="inner_contentDetial">
    	<div class="bg_overlay"></div>
        <div class="content_view">
        	<div class="content_width">
        		<article class="desc animated">
	                <h5 class="title">About Albert Lavenda</h3>
	                <ul class="list_item">
	                    <li><a >Albert Lavenda’s historical origin</a></li>
	                    <li><a>Craftsmanship & Expertises </a></li>
	                    <li><a>Raw materials refinement</a></li>
	                    <li><a>CSR projects</a></li>
	                    <li><a>Awarded Exhibitions</a></li>
	                    <li><a>The company</a></li>
	                    <li><a>Blogs</a></li>
	                    <li><a>Careers</a></li>
	                </ul>
	            </article>
	            <div class="img_block animated"><img src="images/img_view_3.png"></div>
        	</div>
        </div>
    </div>
    
</section>