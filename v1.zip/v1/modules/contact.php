<section class="page detailPage contact" style="display: none;">
    <div class="inner_contentDetial">
    	<div class="bg_overlay"></div>
        <div class="content_view">
        	<div class="content_width">
        		<article class="desc animated">
	                <h5 class="title">Albert Lavenda’s Contact</h3>
	                <ul class="list_item">
	                    <li><a >Contact informations</a></li>
	                    <li><a>Store's Google location maps </a></li>
	                    <li><a>Contact by email</a></li>
	                    <li><a>Social media links</a></li>
	                </ul>
	                <div class="social-box">
	                	<a href="#" class="fb"></a>
	                	<a href="#" class="tw"></a>
	                	<a href="#" class="insta"></a>
	                </div>
	            </article>
	            <div class="img_block animated"><img src="images/contact-house.png"></div>
        	</div>
        </div>
    </div>
    
</section>