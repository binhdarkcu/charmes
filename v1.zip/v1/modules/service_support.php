<section class="page detailPage service_support" style="display: none;">
    <div class="inner_contentDetial">
    	<div class="bg_overlay"></div>
        <div class="content_view">
        	<div class="content_width">
        		<article class="desc animated">
	                <h5 class="title">Albert Lavenda's customer-care services</h3>
	                <ul class="list_item">
	                    <li><a>Jewelries customization service</a></li>
	                    <li><a>Jewelries guides service</a></li>
	                    <li><a>Warranty certificates service</a></li>
	                    <li><a>Shipping & return service</a></li>
	                    <li><a>Online-support service</a></li>
	                    <li><a>Customer care centers</a></li>
	                    <li><a>After-sale supports</a></li>
	                    <li><a>FAQs</a></li>
	                </ul>
	            </article>
        	</div>
        </div>
    </div>
    
</section>